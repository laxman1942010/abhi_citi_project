<template>
  <div class="cloudstorageservice">
       <p id="rcorners"> Replication Storage Services - Host Based </p>
        <p>This service offer ability to replicate data Asynchronously between virtual servers running on Windows platform for Host data replication. It performs virtual sync data followed by an online continuous replication of changes in the file. It provides optional use of LAN, WAN and compression for the data replication.</p>

        <br>
        <li><b>To be able to use this service, A reserve engine should be installed in host machines... Please go to TPM and install latest version available there by searching %AReserverRHA% </b></li>
      <br>
      <br>
      
      

    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Application CSID * </label>
      <div class="col-sm-2">          
        <input type="password" class="form-control" id="pwd" placeholder="Application CSID" name="pwd">
      </div>
      <label class="control-label col-sm-2" for="pwd">
       <button type="button" v-on:click="updateSource('list')" value="Lookup"  class="btn btn-primary btn-xm"> <span class="glyphicon glyphicon-search"></span>  Lookup</button> </label>
    </div>
   
    <p>No Scenario found. Please <a href="" v-on:click="updateSource('track')">click here</a> to create repliation.</p>
    
  </div>
</template>

<script>

export default {
  name: 'cloudstorageservice',
  data () {
    return {
     
    }
  },
  methods: {
    updateSource: function (tab) {
    this.$http.get('https://newsapi.org/v1/sources?language=en')
       .then(response => {
         this.sources = response.data.sources;
         if(tab==='list'){
              this.$emit('showRSSTabs');
        } else if(tab==='track') {
              this.$emit('showTrackTab');
        }
        // alert("Hi"+this.sources[0]);
       });
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.appid {
  font-weight:bold
}


#rcorners {
    border-radius: 5px;
    border: 2px solid ;
    padding: 10px; 
    width: 350px;
        
}
</style>
