<template>

<div class="container">
</br>
  <table class="table">
    <thead>
      <tr>
         <th>#</th>
        <th>Scenario</th>
        <th>Master VM</th>
        <th>Replica VM</th>
        <th>Source</th>
        <th>Destination VM</th>
        <th>State</th>
        <th>Last Updated Date</th>
        
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><input type="radio" name="listgroup" /></td>
        <td>12345 </td>
        <td>sddc-vm-10830</td>
        <td>sddc-vm-10830</td>
         <td>C:\temp </td>
        <td>C:\temp</td>
        <td>Running</td>
        <td>12-Dec-2017 </td>
        
      </tr>
      <tr>
        <td><input type="radio" name="listgroup" /></td>
        <td>83200 </td>
        <td>sddc-vm-10830</td>
        <td>sddc-vm-10830</td>
         <td>C:\temp </td>
        <td>C:\temp</td>
        <td>Running</td>
        <td>12-Dec-2017 </td>
      </tr>
      <tr>
        <td><input type="radio" name="listgroup" /></td>
       <td>29997 </td>
        <td>sddc-vm-10830</td>
        <td>sddc-vm-10830</td>
         <td>C:\temp </td>
        <td>C:\temp</td>
        <td>Running</td>
        <td>12-Dec-2017 </td>
      </tr>
    </tbody>
  </table>

   <br>
   <br>
   <br>

    <div class="row">
   
        <div class="col-sm-5"></div>
        <div class="col-sm-2"> <input type="button" v-on:click="updateSource()" value="Refresh"  class="btn btn-primary btn-xm" ></div>
        <div class="col-sm-5"></div>
    </div>


</div></template>

<script>
export default {
  name: 'listreplication',
  data () {
    return {

    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
header {
  background:#b2cecf;
  padding:20px;
  width:130%;
  margin-left:-120px;
  margin-top:-20px
}
h1 {
  color:black;
  text-align:center;
}
.table-bordered {
  width:100%;

}
td {
  height:30px;
}

th {
  height:40px;
}
</style>

