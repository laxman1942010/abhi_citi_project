<template>
 <div>
     
    <br>
    <br>


    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Application CSID * </label>
      <div class="col-sm-2">          
        <input type="password" class="form-control" id="pwd" placeholder="" name="pwd">
      </div>
      <label class="control-label col-sm-2" for="pwd">
       <button type="button" v-on:click="updateSource()" value="Lookup"  class="btn btn-primary btn-xm"> <span class="glyphicon glyphicon-search"></span>  Lookup</button> </label>
    </div>

    <br>
    <br>
    
     <table class="table">
    <thead>
      <tr>

        <th style="text-align: center;">Scenario</th>
        <th>Master VM</th>
        <th>Replica VM</th>
        <th>Source</th>
        <th>Destination VM</th>
        <th>State</th>
       
        
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><input type="radio" name="managegroup" /> 12345 </td>
        <td>sddc-vm-10830</td>
        <td>sddc-vm-10830</td>
         <td>C:\temp </td>
        <td>C:\temp</td>
        <td>Running</td>
       
        
      </tr>
      <tr>
        <td><input type="radio"  name="managegroup"/> 14433 </td>
        <td>sddc-vm-10830</td>
        <td>sddc-vm-10830</td>
         <td>C:\temp </td>
        <td>C:\temp</td>
        <td>Running</td>
       
      </tr>
      <tr>
       <td><input type="radio" name="managegroup"/> 12123 </td>
        <td>sddc-vm-10830</td>
        <td>sddc-vm-10830</td>
         <td>C:\temp </td>
        <td>C:\temp</td>
        <td>Running</td>
       
      </tr>
    </tbody>
  </table>

<p style="padding:30px;text-align:center"> 




</p>


<div class="row">
   
    <div class="col-sm-1"></div>
    <div class="col-sm-2">
     
        <input type="button" v-on:click="updateSource()" value="Run"  class="btn btn-primary btn-xm" >
    </div>
    
     <div class="col-sm-2">
        <input type="button" v-on:click="updateSource()" value="Suspend"  class="btn btn-primary btn-xm" >
    </div>

    
    <div class="col-sm-2">
      <input type="button" v-on:click="updateSource()" value="Resume"  class="btn btn-primary btn-xm" >
    </div>
     <div class="col-sm-2">
    <input type="button" v-on:click="updateSource()" value="Stop"  class="btn btn-primary btn-xm" >
    </div>

    
    <div class="col-sm-2">
      <input type="button" v-on:click="updateSource()" value="Stop & Delete"  class="btn btn-primary btn-xm" >
    </div>
   
   <div class="col-sm-1"></div>
       
  </div>




  </div>
</template>

<script>





export default {
  name: 'cloudstorageservice',
   data () {
    return {
      
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
header {
  background:#b2cecf;
  padding:20px;
  width:130%;
  margin-left:-120px;
  margin-top:-20px
}
h3 {
  color:black;
  text-align:center;
} 

p {
   
    
    margin: 3px 0px 3px 0px;
    padding: 1px 6px 0px;
    border-top-left-radius: 3px;
    border-top-right-radius: 3px;
    font-family: 'Istok Web', sans-serif;
    font-size: 14px;
    white-space: nowrap;
}

input {
  width:100px;
}

.table-bordered {
  width:100%;

}
td {
  height:30px;
}

th {
  height:40px;
  text-align:left
}

</style>

