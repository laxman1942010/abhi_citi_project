<template>
  <div class="cloudstorageservice">
       <ul class="nav nav-tabs">
		  <li v-on:click="showListReplication()" v-bind:class="{ active: listreplicationtab }"><a href="#">List Replication </a></li>
		  <li v-on:click="showCreateReplication()" v-bind:class="{ active: createreplicationtab }"><a href="#">Create Replication</a></li>
		  <li v-on:click="showManageReplication()" v-bind:class="{ active: managereplicationtab }"><a href="#">Manage Replication</a></li>

       <li v-on:click="showtrackerequest()" v-bind:class="{ active: trackerequest }"><a href="#">Track Request</a></li>
		  
		</ul>
  </div>
</template>

<script>
export default {
  name: 'cloudstorageservice',
  data () {
    return {
      listreplicationtab:true,
      createreplicationtab:false,
      managereplicationtab:false,
      trackerequest:false
    }
  },
  methods: {
    showCreateReplication: function() {
     
      this.createreplicationtab=true;
      this.listreplicationtab = false;
      this.managereplicationtab = false;
      this.trackerequest=false;
      this.$emit('showReplication', 'showcreate');
    },
     showListReplication: function() {
      
      this.createreplicationtab=false;
      this.listreplicationtab = true;
      this.managereplicationtab = false;
      this.trackerequest=false;
       this.$emit('showReplication','showlist');
    },
     showManageReplication: function() {
      
      this.createreplicationtab=false;
      this.listreplicationtab = false;
      this.managereplicationtab = true;
      this.trackerequest=false;
       this.$emit('showReplication','showmanage');
    },
    showtrackerequest: function() {
      
      this.createreplicationtab=false;
      this.listreplicationtab = false;
      this.managereplicationtab = false;
      this.trackerequest=true;
       this.$emit('showReplication','trackrequest');
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.appid {
  font-weight:bold
}
</style>
