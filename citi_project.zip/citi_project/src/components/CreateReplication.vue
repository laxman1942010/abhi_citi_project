<template>
<div class="createreplication">

<br>
<div class="row">
   
    <div class="col-sm-1"></div>
    <div class="col-sm-2"> Application CSID * 
        <a href="#" data-toggle="tooltip" title="Application CSID ">
      <span class="glyphicon glyphicon-info-sign"></span>
      </a> 
      </div>
    
     <div class="col-sm-2"><input type="text"> </div>

    
    <div class="col-sm-2"><button type="button" v-on:click="updateSource()" value="Lookup"  class="btn btn-primary btn-xm"> <span class="glyphicon glyphicon-search"></span>  Lookup</button>
    </div>
     <div class="col-sm-2"></div>
    <div class="col-sm-2"></div>
   <div class="col-sm-1"></div>
       
  </div>
  <br>
  

  <div class="row">
   
    <div class="col-sm-1"></div>
    <div class="col-sm-2">  Billing CSID *  
        <a href="#" data-toggle="tooltip" title="Billing CSID">
          <span class="glyphicon glyphicon-info-sign"></span>
        </a> 
    </div>
    
     <div class="col-sm-2"><input type="text"> </div>

    
    <div class="col-sm-2">
      <button type="button" v-on:click="updateSource()" value="Lookup"  class="btn btn-primary btn-xm"> <span class="glyphicon glyphicon-search"></span>  Lookup</button>
    </div>
     <div class="col-sm-2"></div>
    <div class="col-sm-2"></div>
   <div class="col-sm-1"></div>
       
  </div>


  <br>

  <div class="row">
   
    <div class="col-sm-1"></div>
    <div class="col-sm-2">   Environment  *  
      <a href="#" data-toggle="tooltip" title="Environment ">
      <span class="glyphicon glyphicon-info-sign"></span>
      </a>

    </div>
    
     <div class="col-sm-2"> <input type="radio">DEV  <input type="radio">UAT  <input type="radio">PROD </div>

    
    <div class="col-sm-7"></div>
     
    
       
  </div>


   <br>


  <div class="row">
   
    <div class="col-sm-1"></div>
    <div class="col-sm-2">   Master VM *    
      <a href="#" data-toggle="tooltip" title="Master VM from which actual data is copied.">
      <span class="glyphicon glyphicon-info-sign"></span>
      </a>

    </div>
    
     <div class="col-sm-2">
       
         <select multiple style="width:200px" id="sel2">
        <option>sddc-vm-10830</option>
        <option>sddc-vm-44344</option>
        <option>sddc-vm-43533</option>
        <option>sddc-vm-65633</option>
        
      </select>

     </div>
  
    <div class="col-sm-7"></div>
  </div>

   <br>


  <div class="row">
   
    <div class="col-sm-1"></div>
    <div class="col-sm-2">  Replica VM *   
        <a href="#" data-toggle="tooltip" title="Replica of Master VM. ">
      <span class="glyphicon glyphicon-info-sign"></span>
      </a>

    </div>
    
     <div class="col-sm-2">
       
        <select multiple style="width:200px" id="sel2">
            <option>sddc-vm-10830</option>
            <option>sddc-vm-44344</option>
            <option>sddc-vm-43533</option>
            <option>sddc-vm-65633</option>
            
      </select>

     </div>
  
    <div class="col-sm-7"></div>
  </div>   

   <br>

   <div class="row">
   
    <div class="col-sm-1"></div>
    <div class="col-sm-2">  
    </div>
    
     <div class="col-sm-2">
            
         
           <button type="button" v-on:click="" value="Validate Engine"  class="btn btn-primary btn-xm"> <span class="glyphicon glyphicon-new-window"></span>  Validate Engine</button>
     
          

     </div>
  
    <div class="col-sm-7"></div>
  </div>   

   <br>
      
    
  <div class="row">
   
    <div class="col-sm-1"></div>
    <div class="col-sm-2">  Soruce Directory  * 
        <a href="#" data-toggle="tooltip" title="Source directory from which actual data is copied">
           <span class="glyphicon glyphicon-info-sign"></span>
         </a>

     </div>
    
     <div class="col-sm-2"><input type="text"> </div>

    
    <div class="col-sm-7"></div>
       
  </div>
  <br>

  <div class="row">
   
    <div class="col-sm-1"></div>
    <div class="col-sm-2"> Destination Directory*  
      <a href="#" data-toggle="tooltip" title="Destination directory.">
      <span class="glyphicon glyphicon-info-sign"></span>
      </a>

    </div>
    
     <div class="col-sm-2"><input type="text"> </div>

    
    <div class="col-sm-7"></div>
       
  </div>
  <br>     
  
  <div class="row">
   
    <div class="col-sm-1"></div>
    <div class="col-sm-2">  Administrative Users *  
      <a href="#" data-toggle="tooltip" title="Admin Users">
      <span class="glyphicon glyphicon-info-sign"></span>
      </a>
     
    </div>
    
     <div class="col-sm-2"><input type="text"> </div>
    
    <div class="col-sm-1">
      <button type="button" v-on:click="updateSource()" value="Lookup"  class="btn btn-primary btn-xm"> <span class="glyphicon glyphicon-search"></span>  Lookup</button>
    </div>
     <div class="col-sm-1"> 
      <button type="button" v-on:click="updateSource()" value="Lookup"  class="btn btn-primary btn-xm"> <span class="glyphicon glyphicon-new-window"></span>  Create</button>
     </div>
    <div class="col-sm-4"></div>
   <div class="col-sm-1"></div>

       
  </div>
    


</div>
</template>

<script>
export default {
  name: 'createreplication',
  data () {
    return {
      
    }
  },
   created() {
        $('[data-toggle="tooltip"]').tooltip();
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
header {
  background:#b2cecf;
  padding:20px;
  margin-left:-120px;
  margin-top:-20px
}
h3 {
  color:black;
  text-align:center;
}

</style>
