<template>
  <div class="cloudstorageservice">
      
        <div class="cloudservices">LTFS</div>
        <div class="cloudservices">Object Storage</div>
        <div class="cloudservices">EFS</div>
        <div class="cloudservices">Request</div>
        <div class="cloudservices" v-on:click="showApplicationCSIDPage()">Replications - Host Based</div>



  </div>
</template>

<script>
export default {
  name: 'cloudstorageservice',
  props: ['start'],
  data () {
    return {
      showReplicationPage:false
    }
  },
  methods: {
    showApplicationCSIDPage: function() {
      
      this.$emit('showApplicationCSIDPage');
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1, h2 {
  font-weight: normal;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
.cloudstorageservice{
  margin-top:150px
}
.cloudservices {
  background:#red;
  padding: 40px;
  margin:20px;
  display:inline;
  width:180px;
  height:180px;
  font-weight:bold;
  border-radius: 5px;
  border: 2px solid ;
   
}
</style>
