<template>

  <div class="container" id="app">
    <Header></Header> <br>
    <br>
    <br>

    <CloudStorageService v-on:showApplicationCSIDPage="showApplicationCSIDPage()" v-show="cloudstorageservice"></CloudStorageService> <br>
    
    <ReplicationSSHostBased v-show="cloudstorageservicecsidpage" v-on:showRSSTabs="showRSSTabsPage($event)" ></ReplicationSSHostBased>
    
    <ReplicationSSHostBasedTab v-show="showtabs" v-on:showReplication="showTabContent($event)"></ReplicationSSHostBasedTab>

    <ListReplication v-show="showlistreplication"></ListReplication>

    <CreateReplication  v-show="showcreatereplication"></CreateReplication>

    <ManageReplication  v-show="showmanagereplication"></ManageReplication>

    <TrackRequest  v-show="showtrackrequest"></TrackRequest>
   


  </div>
</template>

<script>

import CloudStorageService from './components/CloudStorageService'
import ReplicationSSHostBased from './components/ReplicationSSHostBased'
import ReplicationSSHostBasedTab from './components/ReplicationSSHostBasedTab'
import Header from './components/Header'
import ListReplication from './components/ListReplication'
import CreateReplication from './components/CreateReplication'
import ManageReplication from './components/ManageReplication'
import TrackRequest from './components/TrackRequest'

export default {
  name: 'app',
  components: {
    CloudStorageService,
    ReplicationSSHostBased,
    ReplicationSSHostBasedTab,
    Header,
    ListReplication,
    CreateReplication,
    ManageReplication,
    TrackRequest
  },
  data () {
    return {
      source: "",
      showpage:false,
      cloudstorageservice: true,
      cloudstorageservicecsidpage:false,
      showlistreplication:false,
      showcreatereplication:false,
      showmanagereplication:false,
      showtrackrequest:false
    }
  },
  methods: {
    sourceChanged: function (source) {
      this.source = source;
    },
    showApplicationCSIDPage: function($event) {
        this.cloudstorageservicecsidpage = !this.cloudstorageservicecsidpage;
        this.cloudstorageservice = !this.cloudstorageservice;
    },
    showRSSTabsPage: function($event) {

         this.cloudstorageservicecsidpage = !this.cloudstorageservicecsidpage;
        this.showtabs = !this.showtabs;
        this.showlistreplication = true;
        this.showcreatereplication = false;
        this.showtrackrequest = false;
    },
    showTabContent: function($event) {
        if($event === 'showlist') {
          this.showlistreplication = true;
          this.showcreatereplication = false;
          this.showmanagereplication = false;
          this.showtrackrequest=false;
        } else if($event === 'showcreate') {
         
           this.showlistreplication = false;
          this.showcreatereplication = true;
          this.showmanagereplication = false;
          this.showtrackrequest=false;
        } else if($event === 'showmanage') {

           this.showlistreplication = false;
           this.showcreatereplication = false;
           this.showmanagereplication = true;
           this.showtrackrequest=false;
        } else if($event === 'trackrequest') {

           this.showlistreplication = false;
           this.showcreatereplication = false;
           this.showmanagereplication = false;
           this.showtrackrequest=true;
        }
  
    }
  }
}
</script>

<style>
  #app {
    padding-top: 20px
  }
</style>
