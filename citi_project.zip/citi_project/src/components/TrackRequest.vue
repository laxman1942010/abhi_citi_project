<template>
  
    <div>
      
        <h3>{{title}}</h3>

    </div>
      
  
</template>

<script>
export default {
  name: 'cloudstorageservice',
  data () {
    return {
      title:'Track Request .....'
    }
  }
}
</script>


<style scoped>

h3 {
  margin-top:120px;
  text-align:center;

}
</style>
