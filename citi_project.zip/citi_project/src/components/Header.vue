<template>
  <header>
      <h3>{{title}}</h3>
  </header>
</template>

<script>
export default {
  name: 'cloudstorageservice',
  data () {
    return {
      title:'Replication Storage Services- Host Based'
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
header {
  background-image: url("../assets/citi.gif");
  background-repeat: repeat-x;
  padding:20px;
  width:130%;
  margin-left:-120px;
  margin-top:-20px
}
h3 {
  color:white;
  text-align:center;

}
</style>
